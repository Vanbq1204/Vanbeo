export default {
    fire: require('../assets/icon_fire.png'),
    question: require('../assets/icon_question.png'),
}