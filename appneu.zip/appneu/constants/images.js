export default {
    background: require('../assets/background.jpeg'),
    computer: require('../assets/computer.png'),
}