export const sum2Number = (x, y) => x + y
export const substract2Number = (x, y) => x - y
export const PI = 3.1416