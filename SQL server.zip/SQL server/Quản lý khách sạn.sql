﻿CREATE DATABASE QUAN_LY_KHACH_SAN
USE QUAN_LY_KHACH_SAN

--TẠO BẢNG KHÁCH HÀNG VÀ THÊM DỮ LIỆU KHÁCH HÀNG

 CREATE TABLE KHACHHANG
  (
    MAKHACHHANG CHAR(20)  PRIMARY KEY, 
    TENKHACHHANG NVARCHAR(30) ,
    DIACHI NVARCHAR(50),
    GIOITINH BIT,
    CMND VARCHAR(30),
    SDT CHAR(11),
    QUOCTICH NVARCHAR(30), 
  )

  INSERT INTO KHACHHANG VALUES 
   ('KH01','PHAM PHUONG THAO','HANOI',1,036304007079,0348982903,'MY'),
   ('KH02','PHAM ANH TUYET','HANOI',1,038904008298,039879807,'ANH'),
   ('KH03','NGUYEN MINH HUYEN','NAMDINH',1,036304007072,0987892307,'VIETNAM'),
   ('KH04','BUI QUOC VAN','THAIBINH',0,034309007079,0349879209,'HANQUOC'),
   ('KH05','ANNA PHAM','NAMDINH',1,034987112009,0348790287,'DUC');



  --TẠO BẢNG CHỨC VỤ VÀ THÊM DỮ LIỆU BẢNG CHỨC VỤ

 CREATE TABLE CHUCVU
  (
    MACHUCVU VARCHAR(10)  PRIMARY KEY,
    TENCHUCVU NVARCHAR(10),
    LUONGCV FLOAT,
	PHUCAPCV FLOAT,
  )
  INSERT INTO CHUCVU VALUES 
   ('A111','QUAN LY',10000,2000),
   ('A112','LE TAN',2000,1000),
   ('A113','BEP TRUONG',7000,2000),
   ('A114','KE TOAN',5000,2300),
   ('A115','NHAN SU',1000,2400);


 --TẠO BẢNG LOẠI PHÒNG VÀ THÊM DỮ LIỆU BẢNG LOẠI PHÒNG

 CREATE TABLE LOAIPHONG
  (
    MALOAIPHONG VARCHAR(10) PRIMARY KEY, 
    TENLOAIPHONG NVARCHAR(30), 
  )

  INSERT INTO LOAIPHONG VALUES 
   ('L01','SUPERIOR'),
   ('L02','DELUXE'),
   ('L03','SUITE'),
   ('L04','STANDARD'),
   ('L05','QUEEN');

 --TẠO BẢNG ĐỒ VÀ THÊM DỮ LIỆU CHO BẢNG ĐỒ

 CREATE TABLE DO
  (
    ID_DO VARCHAR(20)  PRIMARY KEY,
    TENDO NVARCHAR(10),
    GIA INT,
  )

   INSERT INTO DO VALUES 
   ('D12','KHĂN GIẤY',20),
   ('D13','TRÁI CÂY',20),
   ('D14','BIA',30),
   ('D15','BÁNH',30),
   ('D16','THUỐC LÁ',20);

 
 --TẠO BẢNG NH N VIÊN VÀ THÊM DỮ LIỆU CHO BẢNG NH N VIÊN
 CREATE TABLE NHANVIEN
  (
    MANHANVIEN VARCHAR(10) PRIMARY KEY,
    TENNHANVIEN NVARCHAR(30),
    MACHUCVU VARCHAR(10),
    GIOITINH BIT,
    NGAYSINH DATE,
    DIACHI NVARCHAR(50),
   HESOLUONG FLOAT,
   THUCLINH FLOAT,
    CONSTRAINT FK_NHANVIEN_CHUCVU FOREIGN KEY(MACHUCVU) REFERENCES CHUCVU(MACHUCVU), 
  )

  INSERT INTO NHANVIEN VALUES 
   ('NV01','NGUYỄN VĂN NAM','A111', 1,'2000-8-12','HANOI',1.1,NULL),
   ('NV02','BÙI QUANG HUY ','A112', 1,'2001-9-10','HANOI',1.2,NULL),
   ('NV03','NGUYỄN TRỌNG HUY','A113', 1,'2000-9-9','NAMDINH',1.1,NULL),
   ('NV04','HOÀNG MẠNH TIẾN','A114', 0,'2000-9-10','THAIBINH',1.4, NULL),
   ('NV05','TRẦN XU N HOÀNG','A115', 0,'2001-10-9','HANOI',1.27, NULL);



 --TẠO BẢNG PHÒNG VÀ THÊM DỮ LIỆU CHO BẢNG PHÒNG

 CREATE TABLE PHONG
  (
    MAPHONG VARCHAR(10)  PRIMARY KEY, 
    TENPHONG NVARCHAR(20),
    TINHTRANG NVARCHAR(15),
    MALOAIPHONG VARCHAR(10), 
    GIAPHONG INT ,
    CONSTRAINT FK_PHONG_LOAIPHONG FOREIGN KEY(MALOAIPHONG) REFERENCES LOAIPHONG(MALOAIPHONG),
  )

   INSERT INTO PHONG VALUES 
   ('A121','ĐƠN','CÒN TRỐNG','L01',2000),
   ('B122','ĐÔI','CÒN TRỐNG','L02',4000),
   ('C123',N'ĐƠN PHỤ','CÒN TRỐNG','L03',5000),
   ('D124','ĐÔI','ĐÃ BOOK','L04',6000),
   ('E125','ĐƠN','ĐÃ BOOK','L05',7000);




  --TẠO BẢNG PHIẾU ĐẶT HÀNG VÀ THÊM DỮ LIỆU CHO BẢNG PHIẾU ĐẶT PHÒNG
 CREATE TABLE PHIEUDATPHONG
  (
    MAPHIEUDANGKY VARCHAR(10)  PRIMARY KEY, 
	MAPHONG VARCHAR(10), 
    MAKHACHHANG CHAR(20), 
    MANHANVIEN VARCHAR(10), 
    NGAYDEN DATE,
    NGAYDI DATE,
    TRATRUOC INT,
	CONSTRAINT FK_PHIEUDATPHONG_PHONG FOREIGN KEY(MAPHONG) REFERENCES PHONG(MAPHONG),
    CONSTRAINT FK_PHIEUDATPHONG_KHACHHANG FOREIGN KEY(MAKHACHHANG) REFERENCES KHACHHANG(MAKHACHHANG),
    CONSTRAINT FK_PHIEUDATPHONG_NHANVIEN FOREIGN KEY(MANHANVIEN) REFERENCES NHANVIEN(MANHANVIEN),
  )

  INSERT INTO PHIEUDATPHONG VALUES 
   ('DP1','A121','KH01','NV01','2024-1-1','2024-1-10',200),
   ('DP2','B122','KH02','NV02','2024-1-2','2024-1-9',400),
   ('DP3','C123','KH03','NV03','2024-1-3','2024-1-8',700),
   ('DP4','D124','KH04','NV04','2024-1-4','2024-1-18',300),
   ('DP5','E125','KH05','NV05','2024-1-5','2024-1-30',100);


   SELECT * FROM PHIEUDATPHONG
  --TẠO BẢNG HOÁ ĐƠN VÀ THÊM DỮ LIỆU CHO BẢNG HOÁ ĐƠN


 CREATE TABLE HOADON
  (
    ID_HOADON VARCHAR(30) PRIMARY KEY,
    MANHANVIEN VARCHAR(10),
    MAKHACHHANG CHAR(20), 
    NGAYXD DATE,
	TONGSOLUONG INT,
	TONGTIEN FLOAT,
	TONGHOADON FLOAT,
    CONSTRAINT FK_HOADON_NHANVIEN FOREIGN KEY(MANHANVIEN) REFERENCES NHANVIEN(MANHANVIEN),
    CONSTRAINT FK_HOADON_KHACHHANG FOREIGN KEY(MAKHACHHANG) REFERENCES KHACHHANG(MAKHACHHANG),
  )

  INSERT INTO HOADON(ID_HOADON,MANHANVIEN,MAKHACHHANG,NGAYXD) VALUES 
   ('HD01','NV01','KH01','2024-1-4'),
   ('HD02','NV02','KH02','2024-1-4'),
   ('HD03','NV03','KH03','2024-1-5'),
   ('HD04','NV04','KH04','2024-1-6'),
   ('HD05','NV05','KH05','2024-1-6');


  --TẠO BẢNG CHI TIẾT HÓA ĐƠN VÀ THÊM DỮ LIỆU CHO BẢNG CHI TIẾT HÓA ĐƠN
CREATE TABLE CHITIETHOADON
(
    ID_HOADON VARCHAR(30),
    ID_DO VARCHAR(20),
    SOLUONG INT,
	CONSTRAINT PK_CHITIETHOADON PRIMARY KEY(ID_HOADON,ID_DO),
    FOREIGN KEY(ID_HOADON) REFERENCES HOADON,
    FOREIGN KEY(ID_DO) REFERENCES DO
)
GO

  INSERT INTO CHITIETHOADON VALUES 
   ('HD01','D12',10),
   ('HD02','D13',5),
   ('HD03','D14',20),
   ('HD04','D15',5),
   ('HD05','D16',10);

     --THỦ TỤC THÊM KHÁCH HÀNG 
   CREATE or ALTER PROCEDURE ThemKhachHang 
   @MaKhachHang CHAR(20),@TenKhachHang NVARCHAR(30),@DiaChi NVARCHAR(50),
   @GioiTinh BIT, @CMND VARCHAR(30), @SDT CHAR(11), @QuocTich NVARCHAR(30)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM KHACHHANG WHERE MAKHACHHANG = @MaKhachHang)
    BEGIN
        INSERT INTO KHACHHANG 
        VALUES (@MaKhachHang, @TenKhachHang, @DiaChi, @GioiTinh, @CMND, @SDT, @QuocTich)
    END
    ELSE
    BEGIN
        PRINT 'Mã khách hàng đã tồn tại!'
    END
END;
exec ThemKhachHang 'KH02','PHAM VAN MINH','HANOI',1,036304007079,0348982903,'VIET';

select * from KHACHHANG
	-- THỦ TỤC SỬA THÔNG TIN KHÁCH HÀNG 

	CREATE PROCEDURE SuaThongTinKhachHang 
    @MaKhachHang CHAR(20),
    @TenKhachHang NVARCHAR(30),
    @DiaChi NVARCHAR(50),
    @GioiTinh BIT,
    @CMND VARCHAR(30),
    @SDT CHAR(11),
    @QuocTich NVARCHAR(30)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM KHACHHANG WHERE MAKHACHHANG = @MaKhachHang)
    BEGIN
        UPDATE KHACHHANG 
        SET TENKHACHHANG = @TenKhachHang, 
            DIACHI = @DiaChi, 
            GIOITINH = @GioiTinh, 
            CMND = @CMND, 
            SDT = @SDT, 
            QUOCTICH = @QuocTich 
        WHERE MAKHACHHANG = @MaKhachHang
    END
    ELSE
    BEGIN
        PRINT 'Mã khách hàng không tồn tại!'
    END
END;


 -- THỦ TỤC XÓA THÔNG TIN KHÁCH HÀNG 

CREATE OR ALTER PROCEDURE XoaKhachHang 
    @MaKhachHang CHAR(20)
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra xem mã khách hàng có tồn tại trong bảng KHACHHANG không
    IF EXISTS (SELECT 1 FROM KHACHHANG WHERE MAKHACHHANG = @MaKhachHang)
    BEGIN
        -- Xóa tất cả các bản ghi trong bảng CHITIETHOADON liên kết với các hóa đơn của khách hàng cần xóa
        DELETE FROM CHITIETHOADON WHERE ID_HOADON IN (SELECT ID_HOADON FROM HOADON WHERE MAKHACHHANG = @MaKhachHang);

        -- Xóa tất cả các hóa đơn liên quan đến khách hàng cần xóa
        DELETE FROM HOADON WHERE MAKHACHHANG = @MaKhachHang;

        -- Xóa tất cả các phiếu đặt phòng của khách hàng cần xóa
        DELETE FROM PHIEUDATPHONG WHERE MAKHACHHANG = @MaKhachHang;

        -- Xóa thông tin của khách hàng từ bảng KHACHHANG
        DELETE FROM KHACHHANG WHERE MAKHACHHANG = @MaKhachHang;
        
        PRINT 'Đã xóa thông tin của khách hàng và các thông tin liên quan thành công.';
    END
    ELSE
    BEGIN
        PRINT 'Mã khách hàng không tồn tại!';
    END
END;



EXEC XoaKhachHang 'KH02';
SELECT * FROM CHITIETHOADON
Select * from KHACHHANG


-- THỦ TỤC THÊM THÔNG TIN CHỨC VỤ 
CREATE PROCEDURE ThemChucVu 
    @MaChucVu VARCHAR(10),
    @TenChucVu NVARCHAR(10),
    @LuongChucVu FLOAT,
    @PhuCapChucVu FLOAT
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM CHUCVU WHERE MACHUCVU = @MaChucVu)
    BEGIN
        INSERT INTO CHUCVU VALUES (@MaChucVu, @TenChucVu, @LuongChucVu, @PhuCapChucVu)
    END
    ELSE
    BEGIN
        PRINT 'Mã chức vụ đã tồn tại!'
    END
END;
EXEC ThemChucVu'A116','BAO VE',1000,2400;
SELECT * FROM CHUCVU

-- THỦ TỤC SỬA THÔNG TIN CHỨC VỤ 

CREATE PROCEDURE SuaThongTinChucVu 
    @MaChucVu VARCHAR(10),
    @TenChucVu NVARCHAR(10),
    @LuongChucVu FLOAT,
    @PhuCapChucVu FLOAT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM CHUCVU WHERE MACHUCVU = @MaChucVu)
    BEGIN
        UPDATE CHUCVU 
        SET TENCHUCVU = @TenChucVu, 
            LUONGCV = @LuongChucVu, 
            PHUCAPCV = @PhuCapChucVu 
        WHERE MACHUCVU = @MaChucVu
    END
    ELSE
    BEGIN
        PRINT 'Mã chức vụ không tồn tại!'
    END
END;
EXEC SuaThongTinChucVu 'A116','AN NINH',1000,3000

-- THỦ TỤC XÓA THÔNG TIN CHỨC VỤ 
CREATE or Alter PROCEDURE XoaChucVu 
    @MaChucVu VARCHAR(10)
AS
BEGIN
    IF EXISTS (
        SELECT 1 
        FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS AS TC
        JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE AS CU ON TC.CONSTRAINT_NAME = CU.CONSTRAINT_NAME
        WHERE TC.CONSTRAINT_TYPE = 'FOREIGN KEY' 
          AND CU.TABLE_NAME <> 'CHUCVU' 
          AND CU.COLUMN_NAME = 'MACHUCVU'
          AND EXISTS (
            SELECT 1 
            FROM CHUCVU 
            WHERE MACHUCVU = @MaChucVu
        )
    )
    BEGIN
        PRINT 'Không thể xóa chức vụ vì đang có dữ liệu liên quan trong các bảng khác!';
    END
    ELSE
    BEGIN
        DELETE FROM CHUCVU WHERE MACHUCVU = @MaChucVu;
        
        PRINT 'Đã xóa thông tin của chức vụ thành công.';
    END
END;

EXEC XoaChucVu 'A111';
select * from NHANVIEN

-- THỦ TỤC THÊM THÔNG TIN LOAI PHÒNG
CREATE PROCEDURE ThemLoaiPhong 
    @MaLoaiPhong VARCHAR(10),
    @TenLoaiPhong NVARCHAR(30)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM LOAIPHONG WHERE MALOAIPHONG = @MaLoaiPhong)
    BEGIN
        INSERT INTO LOAIPHONG VALUES (@MaLoaiPhong, @TenLoaiPhong)
    END
    ELSE
    BEGIN
        PRINT 'Mã loại phòng đã tồn tại!'
    END
END;
EXEC ThemLoaiPhong 'L01','SUPERIOR';

-- THỦ TỤC SỬA THÔNG TIN LOẠI PHÒNG
CREATE PROCEDURE SuaThongTinLoaiPhong 
    @MaLoaiPhong VARCHAR(10),
    @TenLoaiPhong NVARCHAR(30)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM LOAIPHONG WHERE MALOAIPHONG = @MaLoaiPhong)
    BEGIN
        UPDATE LOAIPHONG 
        SET TENLOAIPHONG = @TenLoaiPhong
        WHERE MALOAIPHONG = @MaLoaiPhong
    END
    ELSE
    BEGIN
        PRINT 'Mã loại phòng không tồn tại!'
    END
END;
-- XÓA THÔNG TIN LOẠI PHÒNG 
CREATE PROCEDURE XoaLoaiPhong 
    @MaLoaiPhong VARCHAR(10)
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra xem mã loại phòng có tồn tại trong bảng LOAIPHONG không
    IF EXISTS (SELECT 1 FROM LOAIPHONG WHERE MALOAIPHONG = @MaLoaiPhong)
    BEGIN
        -- Kiểm tra xem mã loại phòng có tồn tại trong bảng PHONG không
        IF EXISTS (SELECT 1 FROM PHONG WHERE MALOAIPHONG = @MaLoaiPhong)
        BEGIN
            PRINT 'Không thể xóa loại phòng vì đang được sử dụng trong bảng PHONG.';
        END
        ELSE
        BEGIN
            -- Xóa thông tin của loại phòng từ bảng LOAIPHONG
            DELETE FROM LOAIPHONG WHERE MALOAIPHONG = @MaLoaiPhong;
            PRINT 'Đã xóa loại phòng thành công.';
        END
    END
    ELSE
    BEGIN
        PRINT 'Mã loại phòng không tồn tại!';
    END
END;

EXEC XoaLoaiPhong 'L01';


-- THỦ TỤC THÊM THÔNG TIN BẢNG ĐỒ
CREATE PROCEDURE ThemDo 
    @IdDo VARCHAR(20),
    @TenDo NVARCHAR(10),
    @Gia INT
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM DO WHERE ID_DO = @IdDo)
    BEGIN
        INSERT INTO DO VALUES (@IdDo, @TenDo, @Gia)
    END
    ELSE
    BEGIN
        PRINT 'ID đồ đã tồn tại!'
    END
END;
EXEC ThemDo 'D20','MỲ TÔM HẢO HẢO',20
-- THỦ TỤC SỬA THÔNG TIN BẢNG ĐỒ
CREATE PROCEDURE SuaThongTinDo 
    @IdDo VARCHAR(20),
    @TenDo NVARCHAR(10),
    @Gia INT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM DO WHERE ID_DO = @IdDo)
    BEGIN
        UPDATE DO 
        SET TENDO = @TenDo,
            GIA = @Gia
        WHERE ID_DO = @IdDo
    END
    ELSE
    BEGIN
        PRINT 'ID đồ không tồn tại!'
    END
END;
EXEC SuaThongTinDo 'D20','MỲ TÔM BA MIỀN',15


--THỦ TỤC XÓA THÔNG TIN BẢNG ĐỒ 
CREATE or ALTER PROCEDURE XoaDo
    @ID_DO VARCHAR(20)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM DO WHERE ID_DO = @ID_DO)
    BEGIN
        IF EXISTS (SELECT 1 FROM CHITIETHOADON WHERE ID_DO = @ID_DO)
        BEGIN
            PRINT 'Không thể xóa đồ vì đang được sử dụng trong bảng CHITIETHOADON.';
        END
        ELSE
        BEGIN
            DELETE FROM DO WHERE ID_DO = @ID_DO;
            PRINT 'Đã xóa thông tin đồ thành công.';
        END
    END
    ELSE
    BEGIN
        PRINT 'Mã đồ không tồn tại!';
    END
END;

EXEC XoaDo 'D12'
select * from DO
SELECT * FROM CHITIETHOADON


-- THỦ TỤC THÊM THÔNG TIN NHÂN VIÊN 
CREATE OR ALTER PROCEDURE ThemNhanVien 
    @MaNhanVien VARCHAR(10),
    @TenNhanVien NVARCHAR(30),
    @MaChucVu VARCHAR(10),
    @GioiTinh BIT,
    @NgaySinh DATE,
    @DiaChi NVARCHAR(50),
    @HeSoLuong FLOAT,
    @ThuNhap FLOAT
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra xem mã chức vụ có tồn tại trong bảng CHUCVU không
    IF NOT EXISTS (SELECT 1 FROM CHUCVU WHERE MACHUCVU = @MaChucVu)
    BEGIN
        PRINT 'Mã chức vụ không tồn tại!';
        RETURN;
    END

    -- Kiểm tra xem mã nhân viên có bị trùng lặp trong bảng NHANVIEN không
    IF EXISTS (SELECT 1 FROM NHANVIEN WHERE MANHANVIEN = @MaNhanVien)
    BEGIN
        PRINT 'Mã nhân viên đã tồn tại!';
        RETURN;
    END

    -- Thêm nhân viên vào bảng NHANVIEN
    INSERT INTO NHANVIEN (MANHANVIEN, TENNHANVIEN, MACHUCVU, GIOITINH, NGAYSINH, DIACHI, HESOLUONG, THUCLINH)
    VALUES (@MaNhanVien, @TenNhanVien, @MaChucVu, @GioiTinh, @NgaySinh, @DiaChi, @HeSoLuong, @ThuNhap);

    PRINT 'Đã thêm nhân viên thành công.';
END;

-- THỦ TỤC SỬA THÔNG TIN NHÂN VIÊN 
CREATE PROCEDURE SuaThongTinNhanVien
    @MaNhanVien VARCHAR(10),
    @TenNhanVien NVARCHAR(30),
    @MaChucVu VARCHAR(10),
    @GioiTinh BIT,
    @NgaySinh DATE,
    @DiaChi NVARCHAR(50),
    @HeSoLuong FLOAT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM NHANVIEN WHERE MANHANVIEN = @MaNhanVien)
    BEGIN
        IF EXISTS (SELECT 1 FROM CHUCVU WHERE MACHUCVU = @MaChucVu)
        BEGIN
            UPDATE NHANVIEN
            SET TENNHANVIEN = @TenNhanVien,
                MACHUCVU = @MaChucVu,
                GIOITINH = @GioiTinh,
                NGAYSINH = @NgaySinh,
                DIACHI = @DiaChi,
                HESOLUONG = @HeSoLuong
            WHERE MANHANVIEN = @MaNhanVien;
            PRINT 'Sửa thông tin nhân viên thành công.';
        END
        ELSE
        BEGIN
            PRINT 'Mã chức vụ không tồn tại!';
        END
    END
    ELSE
    BEGIN
        PRINT 'Mã nhân viên không tồn tại!';
    END
END;

-- THỦ TỤC XÓA THÔNG TIN NHÂN VIÊN 
CREATE OR ALTER PROCEDURE XoaNhanVien 
    @MaNhanVien VARCHAR(10)
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra xem mã nhân viên có tồn tại trong bảng NHANVIEN không
    IF EXISTS (SELECT 1 FROM NHANVIEN WHERE MANHANVIEN = @MaNhanVien)
    BEGIN
        -- Xóa tất cả các bản ghi trong bảng HOADON liên kết với nhân viên cần xóa
        DELETE FROM HOADON WHERE MANHANVIEN = @MaNhanVien;

        -- Xóa tất cả các bản ghi trong bảng PHIEUDATPHONG liên kết với nhân viên cần xóa
        DELETE FROM PHIEUDATPHONG WHERE MANHANVIEN = @MaNhanVien;

        -- Xóa thông tin của nhân viên từ bảng NHANVIEN
        DELETE FROM NHANVIEN WHERE MANHANVIEN = @MaNhanVien;

        PRINT 'Đã xóa thông tin của nhân viên và các thông tin liên quan thành công.';
    END
    ELSE
    BEGIN
        PRINT 'Mã nhân viên không tồn tại!';
    END
END;

EXEC XoaNhanVien'NV02';
SELECT * FROM NHANVIEN
SELECT * FROM HOADON

-- THỦ TỤC THÊM THÔNG TIN PHÒNG
CREATE OR ALTER PROCEDURE ThemPhong 
    @MaPhong VARCHAR(10),
    @TenPhong NVARCHAR(20),
    @TinhTrang NVARCHAR(15),
    @MaLoaiPhong VARCHAR(10),
    @GiaPhong INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra xem mã phòng có bị trùng lặp không
    IF EXISTS (SELECT 1 FROM PHONG WHERE MAPHONG = @MaPhong)
    BEGIN
        PRINT 'Mã phòng đã tồn tại!';
        RETURN;
    END

    -- Kiểm tra xem mã loại phòng có tồn tại trong bảng LOAIPHONG không
    IF NOT EXISTS (SELECT 1 FROM LOAIPHONG WHERE MALOAIPHONG = @MaLoaiPhong)
    BEGIN
        PRINT 'Mã loại phòng không tồn tại!';
        RETURN;
    END

    -- Thêm phòng vào bảng PHONG
    INSERT INTO PHONG (MAPHONG, TENPHONG, TINHTRANG, MALOAIPHONG, GIAPHONG)
    VALUES (@MaPhong, @TenPhong, @TinhTrang, @MaLoaiPhong, @GiaPhong);

    PRINT 'Đã thêm phòng thành công.';
END;


-- THỦ TỤC SỬA THÔNG TIN PHÒNG 
CREATE OR ALTER PROCEDURE SuaPhong 
    @MaPhong VARCHAR(10),
    @TenPhong NVARCHAR(20),
    @TinhTrang NVARCHAR(15),
    @MaLoaiPhong VARCHAR(10),
    @GiaPhong INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra xem mã phòng có tồn tại trong bảng PHONG không
    IF NOT EXISTS (SELECT 1 FROM PHONG WHERE MAPHONG = @MaPhong)
    BEGIN
        PRINT 'Mã phòng không tồn tại!';
        RETURN;
    END

    -- Kiểm tra xem mã loại phòng có tồn tại trong bảng LOAIPHONG không
    IF NOT EXISTS (SELECT 1 FROM LOAIPHONG WHERE MALOAIPHONG = @MaLoaiPhong)
    BEGIN
        PRINT 'Mã loại phòng không tồn tại!';
        RETURN;
    END

    -- Cập nhật thông tin của phòng trong bảng PHONG
    UPDATE PHONG 
    SET TENPHONG = @TenPhong,
        TINHTRANG = @TinhTrang,
        MALOAIPHONG = @MaLoaiPhong,
        GIAPHONG = @GiaPhong
    WHERE MAPHONG = @MaPhong;

    PRINT 'Đã cập nhật thông tin phòng thành công.';
END;
EXEC SuaPhong 'B122', 'Phòng A', 'Sẵn sàng', 'LP01', 1500000;
SELECT * FROM PHONG
SELECT * FROM LOAIPHONG


-- THỦ TỤC XÓA THÔNG TIN PHÒNG 

CREATE OR ALTER PROCEDURE XoaPhong 
    @MaPhong VARCHAR(10)
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra xem mã phòng có tồn tại trong bảng PHONG không
    IF EXISTS (SELECT 1 FROM PHONG WHERE MAPHONG = @MaPhong)
    BEGIN
        -- Xóa tất cả các bản ghi trong bảng PHIEUDATPHONG liên kết với phòng cần xóa
        DELETE FROM PHIEUDATPHONG WHERE MAPHONG = @MaPhong;

        -- Xóa thông tin của phòng từ bảng PHONG
        DELETE FROM PHONG WHERE MAPHONG = @MaPhong;

        PRINT 'Đã xóa thông tin của phòng và các thông tin liên quan thành công.';
    END
    ELSE
    BEGIN
        PRINT 'Mã phòng không tồn tại!';
    END
END;
SELECT * FROM PHONG
EXEC XoaPhong 'A121';

-- THỦ TỤC THÊM THÔNG TIN PHIẾU ĐẶT PHÒNG
CREATE OR ALTER PROCEDURE ThemPhieuDatPhong 
    @MaPhieuDat VARCHAR(10),@MaPhong VARCHAR(10),@MaKhachHang CHAR(20),@MaNhanVien VARCHAR(10),
    @NgayDen DATE,@NgayDi DATE,@TraTruoc INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra sự tồn tại của mã phòng, mã khách hàng, mã nhân viên trong các bảng tương ứng
    IF EXISTS (SELECT 1 FROM PHONG WHERE MAPHONG = @MaPhong)
       AND EXISTS (SELECT 1 FROM KHACHHANG WHERE MAKHACHHANG = @MaKhachHang)
       AND EXISTS (SELECT 1 FROM NHANVIEN WHERE MANHANVIEN = @MaNhanVien)
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM PHIEUDATPHONG WHERE MAPHIEUDANGKY = @MaPhieuDat)
        BEGIN
            INSERT INTO PHIEUDATPHONG (MAPHIEUDANGKY, MAPHONG, MAKHACHHANG, MANHANVIEN, NGAYDEN, NGAYDI, TRATRUOC)
            VALUES (@MaPhieuDat, @MaPhong, @MaKhachHang, @MaNhanVien, @NgayDen, @NgayDi, @TraTruoc);

            PRINT 'Đã thêm phiếu đặt phòng thành công.';
        END
        ELSE
        BEGIN
            PRINT 'Mã phiếu đặt phòng đã tồn tại!';
        END
    END
    ELSE
    BEGIN
        PRINT 'Mã phòng, mã khách hàng hoặc mã nhân viên không tồn tại trong hệ thống.';
    END
END;


-- THỦ TỤC SỬA THÔNG TIN PHIẾU ĐẶT PHÒNG
CREATE OR ALTER PROCEDURE SuaPhieuDatPhong 
    @MaPhieuDat VARCHAR(10),
    @MaPhong VARCHAR(10),
    @MaKhachHang CHAR(20),
    @MaNhanVien VARCHAR(10),
    @NgayDen DATE,
    @NgayDi DATE,
    @TraTruoc INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra sự tồn tại của mã phiếu đặt phòng trong bảng PHIEUDATPHONG
    IF EXISTS (SELECT 1 FROM PHIEUDATPHONG WHERE MAPHIEUDANGKY = @MaPhieuDat)
    BEGIN
        -- Kiểm tra sự tồn tại của các khóa ngoại (mã phòng, mã khách hàng, mã nhân viên)
        IF EXISTS (SELECT 1 FROM PHONG WHERE MAPHONG = @MaPhong)
           AND EXISTS (SELECT 1 FROM KHACHHANG WHERE MAKHACHHANG = @MaKhachHang)
           AND EXISTS (SELECT 1 FROM NHANVIEN WHERE MANHANVIEN = @MaNhanVien)
        BEGIN
            -- Sửa thông tin phiếu đặt phòng
            UPDATE PHIEUDATPHONG 
            SET MAPHONG = @MaPhong, MAKHACHHANG = @MaKhachHang, MANHANVIEN = @MaNhanVien, 
                NGAYDEN = @NgayDen, NGAYDI = @NgayDi, TRATRUOC = @TraTruoc
            WHERE MAPHIEUDANGKY = @MaPhieuDat;

            PRINT 'Đã cập nhật thông tin phiếu đặt phòng thành công.';
        END
        ELSE
        BEGIN
            PRINT 'Mã phòng, mã khách hàng hoặc mã nhân viên không tồn tại trong hệ thống.';
        END
    END
    ELSE
    BEGIN
        PRINT 'Mã phiếu đặt phòng không tồn tại.';
    END
END;

SELECT * FROM PHIEUDATPHONG

-- THỦ TỤC XÓA PHIẾU ĐẶT PHÒNG
CREATE OR ALTER PROCEDURE XoaPhieuDatPhong 
    @MaPhieuDat VARCHAR(10)
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra xem mã phiếu đặt phòng có tồn tại không
    IF EXISTS (SELECT 1 FROM PHIEUDATPHONG WHERE MAPHIEUDANGKY = @MaPhieuDat)
    BEGIN
        -- Xóa phiếu đặt phòng từ bảng PHIEUDATPHONG
        DELETE FROM PHIEUDATPHONG WHERE MAPHIEUDANGKY = @MaPhieuDat;
        PRINT 'Đã xóa phiếu đặt phòng thành công.';
    END
    ELSE
    BEGIN
        PRINT 'Mã phiếu đặt phòng không tồn tại!';
    END
END;
EXEC XoaPhieuDatPhong 'DP3';

-- THỦ TỤC THÊM THÔNG TIN HÓA ĐƠN 
CREATE OR ALTER PROCEDURE ThemHoaDon
    @MaHoaDon VARCHAR(30),@MaNhanVien VARCHAR(10),@MaKhachHang CHAR(20),@NgayXuat DATE,
    @TongSoLuong INT,@TongTien FLOAT,@TongHoaDon FLOAT
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM NHANVIEN WHERE MANHANVIEN = @MaNhanVien)
    BEGIN
        PRINT 'Mã nhân viên không hợp lệ.';
        RETURN;
    END
    IF NOT EXISTS (SELECT 1 FROM KHACHHANG WHERE MAKHACHHANG = @MaKhachHang)
    BEGIN
        PRINT 'Mã khách hàng không hợp lệ.';
        RETURN; 
    END
    IF NOT EXISTS (SELECT 1 FROM HOADON WHERE ID_HOADON = @MaHoaDon)
    BEGIN
        INSERT INTO HOADON (ID_HOADON, MANHANVIEN, MAKHACHHANG, NGAYXD, TONGSOLUONG, TONGTIEN, TONGHOADON)
        VALUES (@MaHoaDon, @MaNhanVien, @MaKhachHang, @NgayXuat, @TongSoLuong, @TongTien, @TongHoaDon);
        PRINT 'Đã thêm hóa đơn thành công.';
    END
    ELSE
    BEGIN
        PRINT 'Mã hóa đơn đã tồn tại.';
    END
END;

-- THỦ TỤC SỬA THÔNG TIN HÓA ĐƠN 
CREATE OR ALTER PROCEDURE ThemHoaDon 
    @MaHoaDon VARCHAR(30),
    @MaNhanVien VARCHAR(10),
    @MaKhachHang CHAR(20),
    @NgayXuat DATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra xem mã nhân viên tồn tại trong bảng NHANVIEN hay không
    IF NOT EXISTS (SELECT 1 FROM NHANVIEN WHERE MANHANVIEN = @MaNhanVien)
    BEGIN
        PRINT 'Mã nhân viên không hợp lệ. Không thể thêm hóa đơn.';
        RETURN;
    END

    -- Kiểm tra xem mã khách hàng tồn tại trong bảng KHACHHANG hay không
    IF NOT EXISTS (SELECT 1 FROM KHACHHANG WHERE MAKHACHHANG = @MaKhachHang)
    BEGIN
        PRINT 'Mã khách hàng không tồn tại. Không thể thêm hóa đơn.';
        RETURN;
    END

    -- Kiểm tra xem mã hóa đơn đã tồn tại trong bảng HOADON hay không
    IF EXISTS (SELECT 1 FROM HOADON WHERE ID_HOADON = @MaHoaDon)
    BEGIN
        PRINT 'Mã hóa đơn đã tồn tại. Không thể thêm hóa đơn.';
        RETURN;
    END

    -- Thêm hóa đơn vào bảng HOADON
    INSERT INTO HOADON (ID_HOADON, MANHANVIEN, MAKHACHHANG, NGAYXD)
    VALUES (@MaHoaDon, @MaNhanVien, @MaKhachHang, @NgayXuat);

    PRINT 'Thêm hóa đơn thành công.';
END;

SELECT * FROM HOADON
EXEC ThemHoaDon 'HD01', 'NV01', 'KH01', '2024-01-04';

-- THỦ TỤC XÓA HÓA ĐƠN 
CREATE OR ALTER PROCEDURE XoaHoaDon 
    @MaHoaDon VARCHAR(10)
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (SELECT 1 FROM HOADON WHERE ID_HOADON = @MaHoaDon)
    BEGIN
        -- Kiểm tra xem hóa đơn có chứa khóa ngoại trong bảng CHITIETHOADON hay không
        IF EXISTS (SELECT 1 FROM CHITIETHOADON WHERE ID_HOADON = @MaHoaDon)
        BEGIN
            PRINT 'Không thể xóa hóa đơn vì có thông tin chi tiết hóa đơn liên quan.';
        END
        ELSE
        BEGIN
            -- Xóa thông tin của hóa đơn từ bảng HOADON
            DELETE FROM HOADON WHERE ID_HOADON = @MaHoaDon;
            PRINT 'Đã xóa hóa đơn thành công.';
        END
    END
    ELSE
    BEGIN
        PRINT 'Mã hóa đơn không tồn tại!';
    END
END;
SELECT * FROM HOADON
EXEC XoaHoaDon 'HD01'


-- THÊM THÔNG TIN CHI TIẾT HÓA ĐƠN 
CREATE OR ALTER PROCEDURE ThemChiTietHoaDon
    @MaHoaDon VARCHAR(30),
    @MaDo VARCHAR(20),
    @SoLuong INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra xem hóa đơn và đồ đã tồn tại hay không
    IF EXISTS (SELECT 1 FROM HOADON WHERE ID_HOADON = @MaHoaDon)
        AND EXISTS (SELECT 1 FROM DO WHERE ID_DO = @MaDo)
    BEGIN
        -- Kiểm tra xem chi tiết hóa đơn đã tồn tại hay chưa
        IF NOT EXISTS (SELECT 1 FROM CHITIETHOADON WHERE ID_HOADON = @MaHoaDon AND ID_DO = @MaDo)
        BEGIN
            -- Thêm chi tiết hóa đơn vào bảng CHITIETHOADON
            INSERT INTO CHITIETHOADON (ID_HOADON, ID_DO, SOLUONG)
            VALUES (@MaHoaDon, @MaDo, @SoLuong);

            PRINT 'Đã thêm chi tiết hóa đơn thành công.';
        END
        ELSE
        BEGIN
            -- Cập nhật thông tin số lượng của chi tiết hóa đơn
            UPDATE CHITIETHOADON 
            SET SOLUONG = @SoLuong
            WHERE ID_HOADON = @MaHoaDon AND ID_DO = @MaDo;

            PRINT 'Đã cập nhật số lượng của chi tiết hóa đơn.';
        END
    END
    ELSE
    BEGIN
        PRINT 'Hóa đơn hoặc đồ không tồn tại.';
    END
END;

exec ThemChiTietHoaDon 'HD03','D14',5;
SELECT * FROM HOADON
SELECT * FROM DO


-- SỬA THÔNG TIN CHI TIẾT HÓA ĐƠN
CREATE OR ALTER PROCEDURE SuaChiTietHoaDon
    @MaHoaDon VARCHAR(30),
    @MaDo VARCHAR(20),
    @SoLuong INT
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra sự tồn tại của mã hóa đơn và mã đồ trong bảng CHITIETHOADON
    IF EXISTS (SELECT 1 FROM CHITIETHOADON WHERE ID_HOADON = @MaHoaDon AND ID_DO = @MaDo)
    BEGIN
        -- Kiểm tra sự thay đổi của mã hóa đơn và mã đồ
        IF NOT EXISTS (SELECT 1 FROM CHITIETHOADON WHERE ID_HOADON = @MaHoaDon AND ID_DO = @MaDo AND SOLUONG = @SoLuong)
        BEGIN
            -- Kiểm tra sự tồn tại của mã hóa đơn và mã đồ trong bảng HOADON và DO
            IF EXISTS (SELECT 1 FROM HOADON WHERE ID_HOADON = @MaHoaDon) AND EXISTS (SELECT 1 FROM DO WHERE ID_DO = @MaDo)
            BEGIN
                -- Cập nhật thông tin số lượng của chi tiết hóa đơn
                UPDATE CHITIETHOADON 
                SET SOLUONG = @SoLuong
                WHERE ID_HOADON = @MaHoaDon AND ID_DO = @MaDo;

                PRINT 'Đã cập nhật thông tin chi tiết hóa đơn thành công.';
            END
            ELSE
            BEGIN
                PRINT 'Mã hóa đơn hoặc mã đồ không tồn tại trong bảng HOADON hoặc DO.';
            END
        END
        ELSE
        BEGIN
            PRINT 'Thông tin số lượng không có sự thay đổi.';
        END
    END
    ELSE
    BEGIN
        PRINT 'Chi tiết hóa đơn không tồn tại.';
    END
END;
EXEC SuaChiTietHoaDon 'HD03','D14',10
SELECT * FROM CHITIETHOADON
SELECT * FROM HOADON
SELECT * FROM DO

-- THỦ TỤC XÓA THÔNG TIN CHI TIẾT HÓA ĐƠN 
CREATE OR ALTER PROCEDURE XoaChiTietHoaDon
    @ID_HoaDon VARCHAR(30),
    @ID_Do VARCHAR(20)
AS
BEGIN
    SET NOCOUNT ON;

    -- Xóa thông tin chi tiết hóa đơn từ bảng CHITIETHOADON
    DELETE FROM CHITIETHOADON WHERE ID_HOADON = @ID_HoaDon AND ID_DO = @ID_Do;
    PRINT 'Đã xóa thông tin chi tiết hóa đơn thành công.';
END;
SELECT * FROM CHITIETHOADON




