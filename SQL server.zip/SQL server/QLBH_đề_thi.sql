﻿CREATE DATABASE K64_QLBH_đề_thi
USE K64_QLBH_đề_thi;
CREATE TABLE KH (MAKH CHAR(10) PRIMARY KEY, HOTENKH NVARCHAR(50), SOCCCD CHAR(20),DC_LienHe NVARCHAR(20), DT_LienHe CHAR(20), Email CHAR(30) );
INSERT INTO KH (MAKH, HOTENKH, SOCCCD, DC_LienHe, DT_LienHe, Email) 
VALUES 
('KH001', N'Nguyễn Văn A', '1234567890', N'12 Luong Dinh Cua', '0123456789', 'nguyenvana@gmail.com'),
('KH002', N'Trần Thị B', '0987654321', N'3 Pham Ngoc Thach', '0987654321', 'tranthib@gmail.com'),
('KH003', N'Hồ Văn C', '1357924680', N'7 Đại Cồ Việt', '0123456789', 'hovanc@gmail.com'),
('KH004', N'Bùi Nhất A', '3355882213', N'10 Hàng Chiếu', '0343956012', 'buinhata@gmail.com');

CREATE TABLE HH (MAHH CHAR(10) PRIMARY KEY, TENHH NVARCHAR(50), GIATRI BIGINT,SOTIENLAN1 BIGINT, SOTIENCACLANTIEP BIGINT, MAKH CHAR(10)REFERENCES KH(MAKH));
INSERT INTO HH (MAHH, TENHH, GIATRI, SOTIENLAN1, SOTIENCACLANTIEP, MAKH) 
VALUES 
('HH001', N'Máy Giặt', 1000000, 500000, 200000, 'KH001'),
('HH002', N'Tủ Lạnh', 2000000, 800000, 300000, 'KH002'),
('HH003', N'Ti Vi', 1500000, 600000, 250000, 'KH003'),
('HH004', N'Đìa Hòa', 1500000, 600000, 250000, 'KH003'),
('HH005', N'Máy lọc nước', 5000000, 800000, 250000, 'KH001'),
('HH006', N'Nồi Cơm', 500000, 200000, 90000, 'KH004');

CREATE TABLE PT (SOPT CHAR(10) PRIMARY KEY, MAHH CHAR(10) REFERENCES HH(MAHH), MAKH CHAR(10) REFERENCES KH(MAKH),NGAYTHANG DATE,SOTIENTRA BIGINT,LOAIPT INT, GHICHU CHAR(20));
INSERT INTO PT (SOPT, MAHH, MAKH, NGAYTHANG, SOTIENTRA, LOAIPT, GHICHU) 
VALUES 
('PT001', 'HH001', 'KH001', '2024-03-21', 500000, 1, 'Ghi chú cho PT001'),
('PT002', 'HH002', 'KH002', '2024-03-22', 700000, 0, 'Ghi chú cho PT002'),
('PT003', 'HH003', 'KH003', '2024-03-23', 600000, 1, 'Ghi chú cho PT003'),
('PT004', 'HH006', 'KH002', '2024-03-22', 700000, 0, 'Ghi chú cho PT004');

CREATE OR ALTER PROCEDURE SP_THEMPT @SOPT CHAR(10), @MAHH CHAR(10), @MAKH CHAR(10), @NGAYTHANG DATE, @SOTIENTRA BIGINT, @LOAIPT INT, @GHICHU CHAR(20)
AS  
BEGIN
    IF NOT EXISTS (SELECT 1 FROM KH WHERE MAKH = @MAKH)
    BEGIN
        PRINT N'Mã KH không tồn tại trong hệ thống';
    END
    ELSE IF NOT EXISTS (SELECT 1 FROM HH WHERE MAHH = @MAHH)
    BEGIN
        PRINT N'Mã HH không tồn tại trong hệ thống';
    END
    ELSE IF NOT EXISTS (SELECT 1 FROM PT WHERE SOPT = @SOPT)
    BEGIN
        INSERT INTO PT (SOPT, MAHH, MAKH, NGAYTHANG, SOTIENTRA, LOAIPT, GHICHU)
        VALUES (@SOPT, @MAHH, @MAKH, @NGAYTHANG, @SOTIENTRA, @LOAIPT, @GHICHU);
    END
    ELSE
    BEGIN
        PRINT N'Mã số PT này đã tồn tại trong hệ thống';
    END
END;
EXECUTE SP_THEMPT 'PT000', 'HH001', 'KH004', '2024-03-22', 700000, 0, 'Ghi chú cho PT004'

CREATE VIEW SoTienPhaiTra AS
SELECT KH.MAKH, KH.HOTENKH, SUM(PT.SOTIENTRA) AS TongTien
FROM KH
LEFT JOIN PT ON KH.MAKH = PT.MAKH
GROUP BY KH.MAKH, KH.HOTENKH;

SELECT * FROM SoTienPhaiTra

CREATE OR ALTER PROCEDURE SP_THONGKE
    @Option INT,
    @Month INT,
    @Year INT
AS
BEGIN
    IF @Option = 1
    BEGIN
        -- Lựa chọn 1: Số phiếu thu của khách hàng trong tháng
        SELECT COUNT(*) AS SoPhieuThu
        FROM PT
        WHERE MONTH(NGAYTHANG) = @Month AND YEAR(NGAYTHANG) = @Year;
    END
    ELSE IF @Option = 2
    BEGIN
        -- Lựa chọn 2: Số tiền mà mặt hàng đã được thanh toán trả góp trong tháng
        SELECT SUM(SOTIENTRA) AS TongTienTraGop
        FROM PT
        WHERE MONTH(NGAYTHANG) = @Month AND YEAR(NGAYTHANG) = @Year AND LOAIPT = 1;
    END
    ELSE
    BEGIN
        PRINT 'Lựa chọn không hợp lệ';
    END
END;
EXEC SP_THONGKE 2, 3, 2024; 

CREATE OR ALTER PROCEDURE SP_TAO_PHIEU_THU 
    @SOPT CHAR(10),
    @MAHH CHAR(10),
    @MAKH CHAR(10),
    @NGAYTHANG DATE,
    @SOTIENTRA BIGINT,
    @LOAIPT INT,
    @GHICHU CHAR(20)
AS
BEGIN
    -- Kiểm tra xem mã khách hàng và mã hàng hóa có tồn tại trong hệ thống không
    IF NOT EXISTS (SELECT 1 FROM KH WHERE MAKH = @MAKH)
    BEGIN
        PRINT 'Mã khách hàng không tồn tại trong hệ thống';
        RETURN;
    END

    IF NOT EXISTS (SELECT 1 FROM HH WHERE MAHH = @MAHH)
    BEGIN
        PRINT 'Mã hàng hóa không tồn tại trong hệ thống';
        RETURN;
    END

    -- Kiểm tra xem mã số phiếu thu đã tồn tại chưa
    IF EXISTS (SELECT 1 FROM PT WHERE SOPT = @SOPT)
    BEGIN
        PRINT N'Mã số phiếu thu này đã tồn tại trong hệ thống';
        RETURN;
    END

    -- Thêm phiếu thu mới
    INSERT INTO PT (SOPT, MAHH, MAKH, NGAYTHANG, SOTIENTRA, LOAIPT, GHICHU)
    VALUES (@SOPT, @MAHH, @MAKH, @NGAYTHANG, @SOTIENTRA, @LOAIPT, @GHICHU);

    PRINT 'Đã tạo phiếu thu thành công';
END;
EXEC SP_TAO_PHIEU_THU 'PT005', 'HH003', 'KH001', '2024-03-25', 800000, 1, 'Ghi chú cho PT005';
select * from PT


CREATE OR ALTER PROCEDURE SP_XOA_PHIEU_THU
    @SOPT CHAR(10)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM PT WHERE SOPT = @SOPT)
    BEGIN
        DELETE FROM PT WHERE SOPT = @SOPT;
        PRINT N'Đã xóa phiếu thu có mã ' + @SOPT;
    END
    ELSE
    BEGIN
        PRINT N'Không tồn tại phiếu thu có mã ' + @SOPT;
    END
END;
EXECUTE SP_XOA_PHIEU_THU 'PT005';

CREATE OR ALTER TRIGGER TR_UPDATE_SOTIEN_CA_LAN_TIEP
ON PT
AFTER INSERT
AS
BEGIN
    DECLARE @MAHH CHAR(10);
    DECLARE @SOTIENTRA BIGINT;

    -- Lấy mã hàng hóa và số tiền trả góp từ phiếu thu vừa được thêm vào
    SELECT @MAHH = i.MAHH, @SOTIENTRA = i.SOTIENTRA
    FROM inserted i;

    -- Cập nhật số tiền của các lần trả góp tiếp theo (SOTIENCACLANTIEP) cho mã hàng hóa tương ứng
    UPDATE HH
    SET SOTIENCACLANTIEP = SOTIENCACLANTIEP - @SOTIENTRA
    WHERE MAHH = @MAHH;
END;
select * from PT
select * from HH
