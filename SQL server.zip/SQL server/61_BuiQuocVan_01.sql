﻿CREATE DATABASE QuanLyHangHoa;
USE QuanLyHangHoa;

CREATE TABLE HANGHOA (MAHANG INT PRIMARY KEY,TENHANG VARCHAR(100),GIANHAP INT,DONVITINH VARCHAR(50),
NOISX VARCHAR(100),GIAXUAT INT,GHICHU VARCHAR(255));

CREATE TABLE KHACHHANG (MAKHACH INT PRIMARY KEY,TENKHACH VARCHAR(100),DIACHI VARCHAR(255),DIENTHOAI VARCHAR(15),
EMAIL VARCHAR(100));

CREATE TABLE NHACUNGCAP (MANCC INT PRIMARY KEY,TENNCC VARCHAR(100),DIACHINCC VARCHAR(255),SOPHONE VARCHAR(15));

CREATE TABLE PHIEUNHAP (SOPHIEU_N INT PRIMARY KEY,MANCC INT,MAHANG INT,SL_NHAP INT,NGAYNHAP DATE, TIEN_NHAP INT,GHICHU VARCHAR(255),
    FOREIGN KEY (MANCC) REFERENCES NHACUNGCAP(MANCC),
    FOREIGN KEY (MAHANG) REFERENCES HANGHOA(MAHANG));

CREATE TABLE PHIEUXUAT (SOPHIEU_X INT PRIMARY KEY,MAHANG INT,MAKHACH INT,SL_XUAT INT,NGAYXUAT DATE,TIEN_XUAT INT,GHICHU VARCHAR(255),
    FOREIGN KEY (MAHANG) REFERENCES HANGHOA(MAHANG),
    FOREIGN KEY (MAKHACH) REFERENCES KHACHHANG(MAKHACH));
-- Du lieu cho bang HANGHOA
INSERT INTO HANGHOA (MAHANG, TENHANG, GIANHAP, DONVITINH, NOISX, GIAXUAT, GHICHU) VALUES
(1, 'Sua tuoi', 15000, 'Hop', 'Viet Nam', 20000, 'Sua tuoi nguyen chat'),
(2, 'Banh mi', 5000, 'Cai', 'Viet Nam', 8000, 'Banh mi lua mach'),
(3, 'Snack', 8000, 'Goi', 'Viet Nam', 12000, 'Snack osi');
-- Du lieu cho bang KHACHHANG
INSERT INTO KHACHHANG (MAKHACH, TENKHACH, DIACHI, DIENTHOAI, EMAIL) VALUES
(1, 'Nguyen Van A', '123 Duong ABC, Quan 1, TP.HCM', '0909123456', 'nva@gmail.com'),
(2, 'Tran Thi B', '456 Duong DEF, Quan 2, TP.HCM', '0909654321', 'ttb@gmail.com'),
(3, 'Bui Quoc V', '59 Luong Dinh Cua', '0347007115', 'vantbth@gmail.com'),
(4, 'Nguyen Minh B', '11 Tran Phu, Ha Dong', '0962889650', 'nguyenmb@gmail.com');
-- Du lieu cho bang NHACUNGCAP
INSERT INTO NHACUNGCAP (MANCC, TENNCC, DIACHINCC, SOPHONE) VALUES
(1, 'Cong ty Sua ABC', '789 Duong GHI, Quan 3, TP.HCM', '0909123456'),
(2, 'Cong ty Banh DEF', '101 Duong JKL, Quan 4, TP.HCM', '0909654321');

-- Du lieu cho bang PHIEUNHAP
INSERT INTO PHIEUNHAP (SOPHIEU_N, MANCC, MAHANG, SL_NHAP, NGAYNHAP, TIEN_NHAP, GHICHU) VALUES
(1, 1, 1, 100, '2024-05-15', 1500000, 'Nhap sua tuoi dot 1'),
(2, 2, 2, 200, '2024-05-16', 1000000, 'Nhap banh mi dot 1');

-- Du lieu cho bang PHIEUXUAT
INSERT INTO PHIEUXUAT (SOPHIEU_X, MAHANG, MAKHACH, SL_XUAT, NGAYXUAT, TIEN_XUAT, GHICHU) VALUES
(1, 1, 1, 50, '2024-05-17', 1000000, 'Xuat sua tuoi cho khach hang A'),
(2, 2, 2, 100, '2024-05-18', 800000, 'Xuat banh mi cho khach hang B'),
(3, 2, 2, 500, '2024-05-18', 800000, 'Xuat banh mi cho khach hang B');

-- Tạo view tính toán số tiền nhập theo ngày bất kỳ 
CREATE VIEW TinhTienNhapTheoNgay AS
SELECT 
    NGAYNHAP, 
    SUM(TIEN_NHAP) AS TongTienNhap
FROM PHIEUNHAP
GROUP BY NGAYNHAP;
SELECT * FROM TinhTienNhapTheoNgay
WHERE NGAYNHAP = '2024-05-15';
-- Tạo view đưa ra số lượng từng mặt hàng nhập theo một tháng nào đó 
CREATE VIEW SoLuongHangNhapTheoThang AS
SELECT 
    MAHANG, 
    SUM(SL_NHAP) AS TongSoLuongNhap, 
    MONTH(NGAYNHAP) AS Thang, 
    YEAR(NGAYNHAP) AS Nam
FROM PHIEUNHAP
GROUP BY MAHANG, MONTH(NGAYNHAP), YEAR(NGAYNHAP);

select * from SoLuongHangNhapTheoThang
-- Thủ tục thêm thông tin phiếu nhập, kiểm tra mã đã tồn tại trong hệ thống 
CREATE or ALTER PROCEDURE ThemPhieuNhap
    @SoPhieu INT,
    @MaNCC INT,
    @MaHang INT,
    @SLNhap INT,
    @NgayNhap DATE,
    @TienNhap INT,
    @GhiChu NVARCHAR(255)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM PHIEUNHAP WHERE SOPHIEU_N = @SoPhieu)
    BEGIN
        PRINT N'Mã phiếu nhập này đã tồn tại trong hệ thống.'
        RETURN
    END
    IF NOT EXISTS (SELECT 1 FROM NHACUNGCAP WHERE MANCC = @MaNCC)
    BEGIN
        PRINT N'Mã nhà cung cấp này không tồn tại trong hệ thống.'
        RETURN
    END
    IF NOT EXISTS (SELECT 1 FROM HANGHOA WHERE MAHANG = @MaHang)
    BEGIN
        PRINT N'Mã hàng hóa này không tồn tại trong hệ thống.'
        RETURN
    END
    INSERT INTO PHIEUNHAP (SOPHIEU_N, MANCC, MAHANG, SL_NHAP, NGAYNHAP, TIEN_NHAP, GHICHU)
    VALUES (@SoPhieu, @MaNCC, @MaHang, @SLNhap, @NgayNhap, @TienNhap, @GhiChu)

    PRINT N'Thêm thông tin phiếu nhập thành công.'
END
exec ThemPhieuNhap 5, 1, 3, 500, '2024-02-14', NULL, 'Hang moi nhap';
select * from PHIEUNHAP
-- Thủ tục xóa thông tin khách hàng, kiểm tra mã đã tồn tại trong hệ thống
CREATE PROCEDURE XoaKhachHang
    @MaKhach INT
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM KHACHHANG WHERE MAKHACH = @MaKhach)
    BEGIN
        PRINT N'Mã khách hàng này không tồn tại trong hệ thống.'
        RETURN
    END
    DELETE FROM KHACHHANG WHERE MAKHACH = @MaKhach

    PRINT N'Xóa thông tin khách hàng thành công.'
END
EXEC XoaKhachHang @MaKhach = 4;
select * from KHACHHANG
-- Xây dựng trigger tính tiền nhập khi có thêm thông tin phiếu nhập 
CREATE TRIGGER Trigger_TinhTienNhap
ON PHIEUNHAP
AFTER INSERT
AS
BEGIN
    DECLARE @SoPhieu INT, @MaHang INT, @SLNhap INT, @GiaNhap INT;
    
    SELECT @SoPhieu = SOPHIEU_N, @MaHang = MAHANG, @SLNhap = SL_NHAP
    FROM inserted;
    
	SELECT @GiaNhap = GIANHAP FROM HANGHOA WHERE MAHANG = @MaHang;

    UPDATE PHIEUNHAP
    SET TIEN_NHAP = @GiaNhap * @SLNhap
    WHERE SOPHIEU_N = @SoPhieu;
END;
INSERT INTO PHIEUNHAP (SOPHIEU_N, MANCC, MAHANG, SL_NHAP, NGAYNHAP, TIEN_NHAP, GHICHU)
VALUES (4, 1, 1, 100, '2024-05-15', NULL, 'Nhập hàng vào kho');
select * from PHIEUNHAP
-- Thủ tục thống kê số lượng Nhập - Xuất 
CREATE PROCEDURE ThongKeNhapXuatTheoNam
    @LuaChon INT
AS
BEGIN
    IF @LuaChon = 1
    BEGIN
        SELECT YEAR(NGAYNHAP) AS Nam, SUM(SL_NHAP) AS SoLuongNhap
        FROM PHIEUNHAP
        GROUP BY YEAR(NGAYNHAP);
    END
    ELSE IF @LuaChon = 2
    BEGIN
        SELECT YEAR(NGAYXUAT) AS Nam, SUM(SL_XUAT) AS SoLuongXuat
        FROM PHIEUXUAT
        GROUP BY YEAR(NGAYXUAT);
    END
    ELSE
    BEGIN
        PRINT N'Lựa chọn không hợp lệ.';
    END
END;

EXEC ThongKeNhapXuatTheoNam @LuaChon = 1;
EXEC ThongKeNhapXuatTheoNam @LuaChon = 2;



