﻿CREATE DATABASE KHMT_QLTIETKIEM
USE KHMT_QLTIETKIEM
CREATE TABLE KHACHHANG(MAKH CHAR(10) PRIMARY KEY, HOTEN NCHAR(60),SOCCCD INT, DIACHI NCHAR(100), SODIENTHOAI INT, EMAIL NCHAR(50));
INSERT INTO KHACHHANG 
VALUES
	('KH001', 'Nguyen Van A', 123456789, '123 Duong ABC, Quan 1, TP.HCM', 987654321, 'nguyenvana@example.com'),
    ('KH002', 'Tran Thi B', 987654321, '456 Duong XYZ, Quan 2, TP.HCM', 123456789, 'tranthib@example.com'),
    ('KH003', 'Le Van C', 111222333, '789 Duong KLM, Quan 3, TP.HCM', 111222333, 'levanc@example.com'),
    ('KH004', 'Pham Thi D', 444555666, '101 Duong DEF, Quan 4, TP.HCM', 444555666, 'phamthid@example.com'),
    ('KH005', 'Huynh Van E', 777888999, '202 Duong GHI, Quan 5, TP.HCM', 777888999, 'huynhvane@example.com'),
    ('KH006', 'Vu Thi F', 666555444, '303 Duong MNO, Quan 6, TP.HCM', 666555444, 'vuthif@example.com'),
    ('KH008', 'Nguyen Van G', 888777666, '505 Duong UVW, Quan 8, TP.HCM', 999888777, 'nguyenvang@example.com'),
    ('KH009', 'Tran Van H', 333222111, '606 Duong XYZ, Quan 9, TP.HCM', 222333444, 'tranvanh@example.com'),
    ('KH010', 'Le Thi I', 666777888, '707 Duong MNO, Quan 10, TP.HCM', 777666555, 'lethii@example.com');
CREATE TABLE LOAITK (MALOAI CHAR(10) PRIMARY KEY, TENLOAI NCHAR(60), SONGAY INT, LOAITIEN CHAR(10),MUCLAISUAT INT);
INSERT INTO LOAITK
VALUES
    ('LTK001', 'Tiet kiem dien tu', 30, 'VND', 5),
    ('LTK002', 'Tiet kiem truyen thong', 60, 'VND', 7),
    ('LTK003', 'Tiet kiem uu dai', 90, 'VND', 8),
    ('LTK004', 'Tiet kiem dai han', 180, 'VND', 10),
    ('LTK005', 'Tiet kiem ngan han', 15, 'VND', 3),
    ('LTK006', 'Tiet kiem linh hoat', 45, 'VND', 6),
	('LTK008', 'Tiet kiem linh hoat', 45, 'VND', 6),
	('LTK009', 'Tiet kiem linh hoat', 45, 'VND', 6),
	('LTK010', 'Tiet kiem linh hoat', 45, 'VND', 6);
CREATE TABLE SOTK (MASO CHAR(10) PRIMARY KEY,MAKH CHAR(10),SOTIENGUI INT,MALOAI CHAR(10),NGAYGUI DATE,NGAYRUT DATE,
MAHT CHAR(10),TIENLAI INT,SOTIENRUT INT,FOREIGN KEY (MAKH) REFERENCES KHACHHANG(MAKH),FOREIGN KEY (MALOAI) REFERENCES LOAITK(MALOAI),
FOREIGN KEY (MAHT) REFERENCES HINHTHUC(MAHT));
INSERT INTO SOTK 
VALUES
    ('STK001', 'KH001', 10000000, 'LTK001', '2024-01-01', '2024-06-30', 'HT001', 0, 0),
    ('STK002', 'KH002', 20000000, 'LTK002', '2024-02-01', '2024-08-01', 'HT002', 0, 0),
    ('STK003', 'KH003', 30000000, 'LTK003', '2024-03-01', '2024-09-01', 'HT003', 0, 0),
    ('STK004', 'KH004', 40000000, 'LTK004', '2024-04-01', '2024-10-01', 'HT004', 0, 0),
    ('STK005', 'KH005', 50000000, 'LTK005', '2024-05-01', '2024-11-01', 'HT005',0, 0),
    ('STK006', 'KH006', 60000000, 'LTK006', '2024-06-01', '2024-12-01', 'HT006', 0, 0),
    ('STK008', 'KH008', 20000000, 'LTK002', '2023-01-01', '2023-07-01', 'HT008', 0, 0),
    ('STK009', 'KH009', 30000000, 'LTK003', '2023-02-01', '2023-08-01', 'HT009',0, 0),
    ('STK010', 'KH010', 40000000, 'LTK004', '2023-03-01', '2023-09-01', 'HT010',0, 0);

CREATE TABLE HINHTHUC(MAHT CHAR(10) PRIMARY KEY, TENHT NCHAR (60), GHICHU CHAR(50));
INSERT INTO HINHTHUC 
VALUES
    ('HT001', 'Chuyen khoan', 'Chuyen tien qua ngan hang'),
    ('HT002', 'Tien mat', 'Rut/Gui tien mat tai quay giao dich'),
    ('HT003', 'Internet Banking', 'Giao dich tren mang Internet'),
    ('HT004', 'ATM', 'Giao dich qua may rut tien tu dong'),
    ('HT005', 'Ung dung di dong', 'Giao dich qua ung dung di dong'),
    ('HT006', 'Dien thoai', 'Giao dich qua dien thoai'),
    ('HT008', 'Tien mat', 'Rut/Gui tien mat tai quay giao dich'),
    ('HT009', 'Internet Banking', 'Giao dich tren mang Internet'),
    ('HT010', 'ATM', 'Giao dich qua may rut tien tu dong');

SELECT * FROM SOTK
SELECT * FROM HINHTHUC

-- thêm khách hàng
CREATE OR ALTER PROCEDURE SP_THEM_KHACHHANG 
    @MAKH CHAR(10), 
    @HOTEN NCHAR(60),
    @SOCCCD INT, 
    @DIACHI NCHAR(100), 
    @SODIENTHOAI INT,
    @EMAIL NCHAR(50)
AS
BEGIN
    IF NOT EXISTS (SELECT MAKH FROM KHACHHANG WHERE MAKH = @MAKH)
    BEGIN
        INSERT INTO KHACHHANG (MAKH, HOTEN, SOCCCD, DIACHI, SODIENTHOAI, EMAIL)
        VALUES (@MAKH, @HOTEN, @SOCCCD, @DIACHI, @SODIENTHOAI, @EMAIL);
        PRINT N'Them khach hang thanh cong';
    END
    ELSE
    BEGIN
        PRINT N'Ma khach hang da ton tai trong he thong';
    END
END;
EXEC SP_THEM_KHACHHANG 'KH007', 'Tran Van G', 333444555, '404 Duong PQR, Quan 7, TP.HCM', 333444555, 'tranvang@example.com';
-- thêm loại tài khoản 
CREATE OR ALTER PROCEDURE SP_THEM_LOAITK @MALOAI CHAR(10), @TENLOAI NCHAR(60),@SONGAY INT, @LOAITIEN CHAR(10), @MUCLAISUAT INT
AS
BEGIN
    IF NOT EXISTS (SELECT MALOAI FROM LOAITK WHERE MALOAI = @MALOAI)
    BEGIN
        INSERT INTO LOAITK (MALOAI, TENLOAI, SONGAY, LOAITIEN, MUCLAISUAT)
        VALUES (@MALOAI, @TENLOAI, @SONGAY, @LOAITIEN, @MUCLAISUAT);
        PRINT N'Thêm loại tiết kiệm thành công.';
    END
    ELSE
    BEGIN
        PRINT N'Mã loại tiết kiệm đã tồn tại trong hệ thống.';
    END
END;
EXEC SP_THEM_LOAITK 'LTK007', 'Tiet kiem thanh toan', 45, 'VND', 6;
-- thủ tục thêm hình thức 
CREATE OR ALTER PROCEDURE SP_THEM_HINHTHUC @MAHT CHAR(10), @TENHT NCHAR(60),@GHICHU CHAR(50)
AS
BEGIN
    IF NOT EXISTS (SELECT MAHT FROM HINHTHUC WHERE MAHT = @MAHT)
    BEGIN
        INSERT INTO HINHTHUC (MAHT, TENHT, GHICHU)
        VALUES (@MAHT, @TENHT, @GHICHU);
        PRINT N'Thêm hình thức giao dịch thành công.';
    END
    ELSE
    BEGIN
        PRINT N'Mã hình thức đã tồn tại trong hệ thống.';
    END
END;
EXEC SP_THEM_HINHTHUC 'HT007', 'Chuyen qua ung dung di dong', 'Chuyen tien qua ung dung di dong';

-- thủ tục thêm sổ tiết kiệm
CREATE OR ALTER PROCEDURE SP_THEM_SOTK @MASO CHAR(10), @MAKH CHAR(10),@SOTIENGUI INT,@MALOAI CHAR(10),@NGAYGUI DATE,@NGAYRUT DATE,@MAHT CHAR(10),@TIENLAI INT,@SOTIENRUT INT
AS
BEGIN
    IF NOT EXISTS (SELECT MASO FROM SOTK WHERE MASO = @MASO)
    BEGIN
        IF EXISTS (SELECT MAKH FROM KHACHHANG WHERE MAKH = @MAKH) AND
           EXISTS (SELECT MALOAI FROM LOAITK WHERE MALOAI = @MALOAI) AND
           EXISTS (SELECT MAHT FROM HINHTHUC WHERE MAHT = @MAHT)
        BEGIN
            INSERT INTO SOTK (MASO, MAKH, SOTIENGUI, MALOAI, NGAYGUI, NGAYRUT, MAHT, TIENLAI, SOTIENRUT)
            VALUES (@MASO, @MAKH, @SOTIENGUI, @MALOAI, @NGAYGUI, @NGAYRUT, @MAHT, @TIENLAI, @SOTIENRUT);
            PRINT N'Thêm số tiết kiệm thành công.';
        END
        ELSE
        BEGIN
            PRINT N'Mã khách hàng, mã loại tiết kiệm hoặc mã hình thức không hợp lệ.';
        END
    END
    ELSE
    BEGIN
        PRINT N'Mã số tiết kiệm đã tồn tại trong hệ thống.';
    END
END;
EXEC SP_THEM_SOTK 'STK0010', 'KH007', 70000000, 'LTK007', '2024-07-01', '2024-12-31', 'HT007', 2100000, 72100000;
EXEC SP_THEM_SOTK 'STK0011', 'KH007',100000 , 'LTK007', '2024-07-01', '2024-12-31', 'HT007', 0, 0;

-- thủ tục xóa khách hàng 
CREATE OR ALTER PROCEDURE SP_XOA_KHACHHANG 
    @MAKH CHAR(10)
AS
BEGIN
    -- Kiểm tra xem mã khách hàng có tồn tại trong bảng KHACHHANG không
    IF EXISTS (SELECT MAKH FROM KHACHHANG WHERE MAKH = @MAKH)
    BEGIN
        -- Xóa bản ghi từ bảng SOTK liên quan đến mã khách hàng cần xóa
        DELETE FROM SOTK WHERE MAKH = @MAKH;

        -- Xóa bản ghi từ bảng KHACHHANG
        DELETE FROM KHACHHANG WHERE MAKH = @MAKH;

        PRINT N'Xóa khách hàng và các bản ghi liên quan thành công.';
    END
    ELSE
    BEGIN
        PRINT N'Mã khách hàng không tồn tại trong hệ thống.';
    END
END;
EXEC SP_XOA_KHACHHANG 'KH001';
select * from KHACHHANG

-- thủ tục xóa loaitk
CREATE OR ALTER PROCEDURE SP_XOA_LOAITK 
    @MALOAI CHAR(10)
AS
BEGIN
    -- Kiểm tra xem mã loại tiết kiệm có tồn tại trong bảng LOAITK không
    IF EXISTS (SELECT MALOAI FROM LOAITK WHERE MALOAI = @MALOAI)
    BEGIN
        -- Xóa bản ghi từ bảng SOTK liên quan đến mã loại tiết kiệm cần xóa
        DELETE FROM SOTK WHERE MALOAI = @MALOAI;

        -- Xóa bản ghi từ bảng LOAITK
        DELETE FROM LOAITK WHERE MALOAI = @MALOAI;

        PRINT N'Xóa loại tiết kiệm và các bản ghi liên quan thành công.';
    END
    ELSE
    BEGIN
        PRINT N'Mã loại tiết kiệm không tồn tại trong hệ thống.';
    END
END;
EXEC SP_XOA_LOAITK 'LTK007';
select * from LOAITK
-- thủ tục xóa hình thức 
CREATE OR ALTER PROCEDURE SP_XOA_HINHTHUC 
    @MAHT CHAR(10)
AS
BEGIN
    -- Kiểm tra xem mã hình thức giao dịch có tồn tại trong bảng HINHTHUC không
    IF EXISTS (SELECT MAHT FROM HINHTHUC WHERE MAHT = @MAHT)
    BEGIN
        -- Xóa bản ghi từ bảng SOTK liên quan đến mã hình thức giao dịch cần xóa
        DELETE FROM SOTK WHERE MAHT = @MAHT;

        -- Xóa bản ghi từ bảng HINHTHUC
        DELETE FROM HINHTHUC WHERE MAHT = @MAHT;

        PRINT N'Xóa hình thức giao dịch và các bản ghi liên quan thành công.';
    END
    ELSE
    BEGIN
        PRINT N'Mã hình thức không tồn tại trong hệ thống.';
    END
END;
EXEC SP_XOA_HINHTHUC 'HT007';
select * from HINHTHUC
-- thủ tục xóa sổ tiết kiệm
CREATE OR ALTER PROCEDURE SP_XOA_SOTK 
    @MASO CHAR(10)
AS
BEGIN
    -- Kiểm tra xem mã số tiết kiệm có tồn tại trong bảng SOTK không
    IF EXISTS (SELECT MASO FROM SOTK WHERE MASO = @MASO)
    BEGIN
        -- Xóa bản ghi từ bảng SOTK
        DELETE FROM SOTK WHERE MASO = @MASO;

        PRINT N'Xóa số tiết kiệm thành công.';
    END
    ELSE
    BEGIN
        PRINT N'Mã số tiết kiệm không tồn tại trong hệ thống.';
    END
END;
EXEC SP_XOA_SOTK 'STK007';
select * from SOTK
-- tạo view chi tiết
CREATE VIEW ChiTietSoTietKiem AS
SELECT SOTK.MASO,KHACHHANG.HOTEN AS TEN_KHACH_HANG,KHACHHANG.DIACHI,KHACHHANG.SODIENTHOAI,LOAITK.TENLOAI AS LOAI_TIET_KIEM,
    LOAITK.SONGAY AS SO_NGAY_GUI,LOAITK.LOAITIEN AS LOAI_TIEN,LOAITK.MUCLAISUAT AS MUC_LAI_SUAT,SOTK.SOTIENGUI,SOTK.NGAYGUI,SOTK.NGAYRUT,
    HINHTHUC.TENHT AS TEN_HINH_THUC,HINHTHUC.GHICHU AS GHI_CHU_HINH_THUC,SOTK.TIENLAI,SOTK.SOTIENRUT
FROM 
    SOTK, KHACHHANG, LOAITK, HINHTHUC
WHERE 
    SOTK.MAKH = KHACHHANG.MAKH
    AND SOTK.MALOAI = LOAITK.MALOAI
    AND SOTK.MAHT = HINHTHUC.MAHT;

SELECT * FROM ChiTietSoTietKiem

-- khách hàng gửi tiền nhiều nhất năm 2023
CREATE VIEW Maxtiengui2023 AS
SELECT 
    KH.MAKH,
    KH.HOTEN AS TEN_KHACH_HANG,
    KH.DIACHI,
    KH.SODIENTHOAI,
    SOTK.SOTIENGUI,
    SOTK.NGAYGUI,
    SOTK.NGAYRUT
FROM 
    KHACHHANG KH
    INNER JOIN SOTK ON KH.MAKH = SOTK.MAKH
WHERE 
    YEAR(SOTK.NGAYGUI) = 2023
    AND SOTK.SOTIENGUI = (
        SELECT MAX(SOTIENGUI)
        FROM SOTK
        WHERE YEAR(NGAYGUI) = 2023
    );
select * from Maxtiengui2023
-- số lượng 
CREATE VIEW SoLuongSoTietKiem2024 AS
SELECT 
    KH.MAKH,
    KH.HOTEN AS TEN_KHACH_HANG,
    COUNT(SOTK.MASO) AS SO_LUONG_SO_TIET_KIEM_GUI
FROM 
    KHACHHANG KH
    INNER JOIN SOTK ON KH.MAKH = SOTK.MAKH
WHERE 
    YEAR(SOTK.NGAYGUI) = 2024
GROUP BY 
    KH.MAKH, KH.HOTEN;
select * from SoLuongSoTietKiem2024


UPDATE SOTK
SET TIENLAI = 0, SOTIENRUT = 0;


-- Tạo hoặc thay đổi thủ tục tính toán số tiền rút của từng sổ tiết kiệm
CREATE OR ALTER PROCEDURE SP_TINHLAI_SOTIENGUI
AS
BEGIN
    -- Cập nhật số tiền lãi và số tiền gửi cho mỗi sổ tiết kiệm
    UPDATE SOTK
    SET TIENLAI = ROUND(SOTIENGUI * LK.MUCLAISUAT / 100.0, 0),
        SOTIENRUT = SOTIENGUI + ROUND(SOTIENGUI * LK.MUCLAISUAT / 100.0, 0)
    FROM SOTK
    INNER JOIN LOAITK LK ON SOTK.MALOAI = LK.MALOAI;

    PRINT N'Tính toán số tiền lãi và số tiền gửi của từng sổ tiết kiệm thành công.';
END;
exec SP_TINHLAI_SOTIENGUI

select * from SOTK
--Viết Trigger Tính số lãi và tiền rút khi đáo hạn (khi có thêm sổ tiết kiệm mới). Công thức tính: Tiền lãi = Số tiền gửi x lãi suất (%năm) x số ngày gửi/360
CREATE OR ALTER TRIGGER TR_TINHLAI_SOTIENRUT
ON SOTK
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @TienLai INT;
    DECLARE @SoTienRut INT;

    -- Lấy thông tin về số tiền gửi và mã loại tiết kiệm của sổ tiết kiệm mới được thêm vào
    SELECT @TienLai = i.SOTIENGUI * l.MUCLAISUAT * DATEDIFF(day, i.NGAYGUI, i.NGAYRUT) / 360,
           @SoTienRut = i.SOTIENGUI + (i.SOTIENGUI * l.MUCLAISUAT / 100.0)
    FROM inserted i
    INNER JOIN LOAITK l ON i.MALOAI = l.MALOAI;

    -- Cập nhật số tiền lãi và số tiền rút cho sổ tiết kiệm mới
    UPDATE SOTK
    SET TIENLAI = @TienLai,
        SOTIENRUT = @SoTienRut
    FROM SOTK
    INNER JOIN inserted i ON SOTK.MASO = i.MASO;

END;


