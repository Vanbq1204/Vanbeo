﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAITHUCHANHSO1
{
    public partial class frmNhapDuLieu1 : Form
    {
        public frmNhapDuLieu1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmNhapDuLieu1_Load(object sender, EventArgs e)
        {
            cboKhoa.Items.Add("Khoa HTTT");
            cboKhoa.Items.Add("Khoa Trí tuệ nhân tạo");//add dữ liệu trên code


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();// chỉ thoát form đang chạy , nếu có form main thì không đóng form đó
            //Application.Exit(); thoát toàn bộ form đang chạy, nếu có cả form main thì đóng luôn
        }

        private void btnNHAP1_Click(object sender, EventArgs e)
        {
            FrmTimKiem1 frm1 = new FrmTimKiem1();
            frm1.Show();
        }

        private void btnXOADL_Click(object sender, EventArgs e)
        {

        }

        private void cboKhoa_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
