﻿namespace BAITHUCHANHSO1
{
    partial class FrmThucHanh1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.G1 = new System.Windows.Forms.GroupBox();
            this.chk1 = new System.Windows.Forms.CheckBox();
            this.chk2 = new System.Windows.Forms.CheckBox();
            this.chk3 = new System.Windows.Forms.CheckBox();
            this.chk4 = new System.Windows.Forms.CheckBox();
            this.chk5 = new System.Windows.Forms.CheckBox();
            this.G2 = new System.Windows.Forms.GroupBox();
            this.opt1 = new System.Windows.Forms.RadioButton();
            this.opt2 = new System.Windows.Forms.RadioButton();
            this.G3 = new System.Windows.Forms.GroupBox();
            this.opt4 = new System.Windows.Forms.RadioButton();
            this.opt3 = new System.Windows.Forms.RadioButton();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnHienThi = new System.Windows.Forms.Button();
            this.G1.SuspendLayout();
            this.G2.SuspendLayout();
            this.G3.SuspendLayout();
            this.SuspendLayout();
            // 
            // G1
            // 
            this.G1.Controls.Add(this.chk5);
            this.G1.Controls.Add(this.chk4);
            this.G1.Controls.Add(this.chk3);
            this.G1.Controls.Add(this.chk2);
            this.G1.Controls.Add(this.chk1);
            this.G1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G1.Location = new System.Drawing.Point(125, 48);
            this.G1.Name = "G1";
            this.G1.Size = new System.Drawing.Size(178, 230);
            this.G1.TabIndex = 0;
            this.G1.TabStop = false;
            this.G1.Text = "Các môn học :";
            this.G1.Enter += new System.EventHandler(this.G1_Enter);
            // 
            // chk1
            // 
            this.chk1.AutoSize = true;
            this.chk1.Location = new System.Drawing.Point(6, 34);
            this.chk1.Name = "chk1";
            this.chk1.Size = new System.Drawing.Size(84, 29);
            this.chk1.TabIndex = 0;
            this.chk1.Text = "Toán";
            this.chk1.UseVisualStyleBackColor = true;
            // 
            // chk2
            // 
            this.chk2.AutoSize = true;
            this.chk2.Location = new System.Drawing.Point(6, 69);
            this.chk2.Name = "chk2";
            this.chk2.Size = new System.Drawing.Size(75, 29);
            this.chk2.TabIndex = 0;
            this.chk2.Text = "Văn";
            this.chk2.UseVisualStyleBackColor = true;
            // 
            // chk3
            // 
            this.chk3.AutoSize = true;
            this.chk3.Location = new System.Drawing.Point(6, 104);
            this.chk3.Name = "chk3";
            this.chk3.Size = new System.Drawing.Size(76, 29);
            this.chk3.TabIndex = 0;
            this.chk3.Text = "Anh";
            this.chk3.UseVisualStyleBackColor = true;
            // 
            // chk4
            // 
            this.chk4.AutoSize = true;
            this.chk4.Checked = true;
            this.chk4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chk4.Location = new System.Drawing.Point(6, 139);
            this.chk4.Name = "chk4";
            this.chk4.Size = new System.Drawing.Size(93, 29);
            this.chk4.TabIndex = 0;
            this.chk4.Text = "Vật lý";
            this.chk4.UseVisualStyleBackColor = true;
            // 
            // chk5
            // 
            this.chk5.AutoSize = true;
            this.chk5.Location = new System.Drawing.Point(6, 174);
            this.chk5.Name = "chk5";
            this.chk5.Size = new System.Drawing.Size(147, 29);
            this.chk5.TabIndex = 0;
            this.chk5.Text = "Nghệ thuật";
            this.chk5.UseVisualStyleBackColor = true;
            // 
            // G2
            // 
            this.G2.Controls.Add(this.opt2);
            this.G2.Controls.Add(this.opt1);
            this.G2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G2.Location = new System.Drawing.Point(396, 48);
            this.G2.Name = "G2";
            this.G2.Size = new System.Drawing.Size(200, 109);
            this.G2.TabIndex = 1;
            this.G2.TabStop = false;
            this.G2.Text = "Giới tính : ";
            // 
            // opt1
            // 
            this.opt1.AutoSize = true;
            this.opt1.Checked = true;
            this.opt1.Location = new System.Drawing.Point(19, 34);
            this.opt1.Name = "opt1";
            this.opt1.Size = new System.Drawing.Size(81, 29);
            this.opt1.TabIndex = 0;
            this.opt1.TabStop = true;
            this.opt1.Text = "Nam";
            this.opt1.UseVisualStyleBackColor = true;
            this.opt1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // opt2
            // 
            this.opt2.AutoSize = true;
            this.opt2.Location = new System.Drawing.Point(19, 69);
            this.opt2.Name = "opt2";
            this.opt2.Size = new System.Drawing.Size(64, 29);
            this.opt2.TabIndex = 0;
            this.opt2.Text = "Nữ";
            this.opt2.UseVisualStyleBackColor = true;
            this.opt2.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // G3
            // 
            this.G3.Controls.Add(this.opt4);
            this.G3.Controls.Add(this.opt3);
            this.G3.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.G3.Location = new System.Drawing.Point(396, 169);
            this.G3.Name = "G3";
            this.G3.Size = new System.Drawing.Size(224, 109);
            this.G3.TabIndex = 1;
            this.G3.TabStop = false;
            this.G3.Text = "Tốt nghiệp :";
            // 
            // opt4
            // 
            this.opt4.AutoSize = true;
            this.opt4.Location = new System.Drawing.Point(19, 69);
            this.opt4.Name = "opt4";
            this.opt4.Size = new System.Drawing.Size(196, 29);
            this.opt4.TabIndex = 0;
            this.opt4.Text = "Chưa tốt nghiệp";
            this.opt4.UseVisualStyleBackColor = true;
            this.opt4.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // opt3
            // 
            this.opt3.AutoSize = true;
            this.opt3.Checked = true;
            this.opt3.Location = new System.Drawing.Point(19, 34);
            this.opt3.Name = "opt3";
            this.opt3.Size = new System.Drawing.Size(169, 29);
            this.opt3.TabIndex = 0;
            this.opt3.TabStop = true;
            this.opt3.Text = "Đã tốt nghiệp";
            this.opt3.UseVisualStyleBackColor = true;
            this.opt3.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.Location = new System.Drawing.Point(603, 352);
            this.btnThoat.Margin = new System.Windows.Forms.Padding(10);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Padding = new System.Windows.Forms.Padding(4);
            this.btnThoat.Size = new System.Drawing.Size(133, 43);
            this.btnThoat.TabIndex = 2;
            this.btnThoat.Text = "THOÁT";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnHienThi
            // 
            this.btnHienThi.Font = new System.Drawing.Font("Times", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHienThi.Location = new System.Drawing.Point(380, 352);
            this.btnHienThi.Name = "btnHienThi";
            this.btnHienThi.Size = new System.Drawing.Size(140, 43);
            this.btnHienThi.TabIndex = 3;
            this.btnHienThi.Text = "Hiển thị";
            this.btnHienThi.UseVisualStyleBackColor = true;
            this.btnHienThi.Click += new System.EventHandler(this.btnHienThi_Click);
            // 
            // FrmThucHanh1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnHienThi);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.G3);
            this.Controls.Add(this.G2);
            this.Controls.Add(this.G1);
            this.Name = "FrmThucHanh1";
            this.Text = "FrmThucHanh1";
            this.G1.ResumeLayout(false);
            this.G1.PerformLayout();
            this.G2.ResumeLayout(false);
            this.G2.PerformLayout();
            this.G3.ResumeLayout(false);
            this.G3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox G1;
        private System.Windows.Forms.CheckBox chk1;
        private System.Windows.Forms.CheckBox chk5;
        private System.Windows.Forms.CheckBox chk4;
        private System.Windows.Forms.CheckBox chk3;
        private System.Windows.Forms.CheckBox chk2;
        private System.Windows.Forms.GroupBox G2;
        private System.Windows.Forms.RadioButton opt1;
        private System.Windows.Forms.RadioButton opt2;
        private System.Windows.Forms.GroupBox G3;
        private System.Windows.Forms.RadioButton opt4;
        private System.Windows.Forms.RadioButton opt3;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnHienThi;
    }
}