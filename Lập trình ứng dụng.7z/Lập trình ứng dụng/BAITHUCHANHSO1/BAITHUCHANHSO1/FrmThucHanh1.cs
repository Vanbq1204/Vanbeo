﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAITHUCHANHSO1
{
    public partial class FrmThucHanh1 : Form
    {
        public FrmThucHanh1()
        {
            InitializeComponent();
        }

        private void G1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnHienThi_Click(object sender, EventArgs e)
        {
            String s = " ";
            if (opt1.Checked == true)
                MessageBox.Show("Đây là sinh viên Nam");
            if (opt2.Checked == true)
                MessageBox.Show("Đây là sinh viên Nữ");
            if (opt1.Checked == true)
                MessageBox.Show("Sinh viên đã tốt nghiệp");
        }
    }
}
