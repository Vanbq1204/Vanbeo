﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAITHUCHANHSO1
{
    public partial class Formtinhtoan : Form
    {
        public Formtinhtoan()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            +
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnTong_Click(object sender, EventArgs e)
        {
            String So1 = textso1.Text;
            String So2 = textso2.Text;
            int i1 = int.Parse( So1 );
            int i2 = int.Parse( So2 );
            long Tong = 0;
            Tong = i1 + i2;
            textKetQua.Text = Tong.ToString();
        }
    }
}
