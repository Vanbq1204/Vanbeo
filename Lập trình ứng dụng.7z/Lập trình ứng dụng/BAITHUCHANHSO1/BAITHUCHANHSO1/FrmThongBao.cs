﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAITHUCHANHSO1
{
    public partial class FrmThongBao : Form
    {
        public FrmThongBao()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboNgay_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboNgay_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FrmThongBao_Load(object sender, EventArgs e)
        {
            for (int i = 0; i<=31;i++)
                cboNgay.Items.Add(i);
                cboNgay.SelectedIndex = 0;
            for (int i = 0; i <= 12; i++)
                cboThang.Items.Add(i);
                cboThang.SelectedIndex = 0;
            for (int i = 1987; i <=2007; i++)
                cboNam.Items.Add(i);
                cboNam.SelectedIndex = 0;
            lst1.Items.Add("Môn số 1");
            lst1.Items.Add("Môn số 2");
            lst1.Items.Add("Môn số 3");
            lst1.Items.Add("Môn số 4");
            lst1.Items.Add("Môn số 5");
            lst2.Items.Add("Môn số 6");
            lst2.Items.Add("Môn số 7");
            lst2.Items.Add("Môn số 8");
            lst2.Items.Add("Môn số 9");
            lst2.Items.Add("Môn số 10");
        }

        private void lst1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            for(int i = 0; i<lst1.Items.Count; i++)
            {
                lst2.Items.Add(lst1.Items[i]);
            }
            for (int i = 0; i < lst2.Items.Count; i++)
            {
                lst1.Items.Remove(lst2.Items[i]);
            }
        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if(lst1.SelectedItems.Count >0)
            {
                lst2.Items.Add(lst1.SelectedItem);
                lst1.Items.Remove(lst1.SelectedItem);
            }
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            if (lst2.SelectedItems.Count > 0)
            {
                lst1.Items.Add(lst2.SelectedItem);
                lst2.Items.Remove(lst2.SelectedItem);
            }
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            for(int i = 0;i<lst2.Items.Count;i++)
            {
                lst1.Items.Add(lst2.Items[i]);
            }
            for (int i = 0; i < lst1.Items.Count; i++)
            {
                lst2.Items.Remove(lst1.Items[i]);
            }
        }
    }
}
