﻿namespace BAITHUCHANHSO1
{
    partial class frmNhapDuLieu1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textHOTEN = new System.Windows.Forms.TextBox();
            this.textPass = new System.Windows.Forms.TextBox();
            this.lblHoTen = new System.Windows.Forms.Label();
            this.lblMaKhau = new System.Windows.Forms.Label();
            this.textTieuDe = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnNHAP1 = new System.Windows.Forms.Button();
            this.btnXOADL = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.btnTIMKIEM = new System.Windows.Forms.Button();
            this.cboKhoa = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textHOTEN
            // 
            this.textHOTEN.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textHOTEN.Location = new System.Drawing.Point(227, 193);
            this.textHOTEN.MaxLength = 30;
            this.textHOTEN.Name = "textHOTEN";
            this.textHOTEN.Size = new System.Drawing.Size(248, 34);
            this.textHOTEN.TabIndex = 0;
            this.textHOTEN.Text = "NGUYEN VAN A";
            this.textHOTEN.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textPass
            // 
            this.textPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textPass.Location = new System.Drawing.Point(227, 252);
            this.textPass.Name = "textPass";
            this.textPass.PasswordChar = '*';
            this.textPass.Size = new System.Drawing.Size(248, 34);
            this.textPass.TabIndex = 1;
            this.textPass.Text = "NGUYEN VAN A";
            this.textPass.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblHoTen
            // 
            this.lblHoTen.AutoSize = true;
            this.lblHoTen.Font = new System.Drawing.Font("Times", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHoTen.Location = new System.Drawing.Point(77, 193);
            this.lblHoTen.Name = "lblHoTen";
            this.lblHoTen.Size = new System.Drawing.Size(134, 25);
            this.lblHoTen.TabIndex = 2;
            this.lblHoTen.Text = "Họ Và Tên :";
            // 
            // lblMaKhau
            // 
            this.lblMaKhau.AutoSize = true;
            this.lblMaKhau.Font = new System.Drawing.Font("Times", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaKhau.Location = new System.Drawing.Point(77, 258);
            this.lblMaKhau.Name = "lblMaKhau";
            this.lblMaKhau.Size = new System.Drawing.Size(131, 25);
            this.lblMaKhau.TabIndex = 2;
            this.lblMaKhau.Text = "Mật Khẩu :";
            this.lblMaKhau.Click += new System.EventHandler(this.label1_Click);
            // 
            // textTieuDe
            // 
            this.textTieuDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTieuDe.Location = new System.Drawing.Point(142, 88);
            this.textTieuDe.Name = "textTieuDe";
            this.textTieuDe.Size = new System.Drawing.Size(476, 34);
            this.textTieuDe.TabIndex = 3;
            this.textTieuDe.Text = "THÔNG TIN SINH VIÊN TRƯỜNG ABC";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(227, 313);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(248, 34);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "HÀ NỘI";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(77, 319);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Quê Quán :";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(227, 366);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(248, 34);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "10.000.000VNĐ";
            this.textBox2.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(77, 372);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Học Bổng :";
            this.label2.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnNHAP1
            // 
            this.btnNHAP1.Font = new System.Drawing.Font("Times", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNHAP1.Location = new System.Drawing.Point(520, 227);
            this.btnNHAP1.Name = "btnNHAP1";
            this.btnNHAP1.Size = new System.Drawing.Size(155, 46);
            this.btnNHAP1.TabIndex = 4;
            this.btnNHAP1.TabStop = false;
            this.btnNHAP1.Text = "Nhập dữ liệu";
            this.btnNHAP1.UseVisualStyleBackColor = true;
            this.btnNHAP1.Click += new System.EventHandler(this.btnNHAP1_Click);
            // 
            // btnXOADL
            // 
            this.btnXOADL.Font = new System.Drawing.Font("Times", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXOADL.Location = new System.Drawing.Point(520, 298);
            this.btnXOADL.Name = "btnXOADL";
            this.btnXOADL.Size = new System.Drawing.Size(155, 46);
            this.btnXOADL.TabIndex = 4;
            this.btnXOADL.TabStop = false;
            this.btnXOADL.Text = "Xóa dữ liệu";
            this.btnXOADL.UseVisualStyleBackColor = true;
            this.btnXOADL.Click += new System.EventHandler(this.btnXOADL_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Times", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(520, 359);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(155, 46);
            this.button2.TabIndex = 4;
            this.button2.TabStop = false;
            this.button2.Text = "Sửa dữ liệu";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Times", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThoat.Location = new System.Drawing.Point(503, 498);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(193, 46);
            this.btnThoat.TabIndex = 4;
            this.btnThoat.TabStop = false;
            this.btnThoat.Text = "THOÁT";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnTIMKIEM
            // 
            this.btnTIMKIEM.Font = new System.Drawing.Font("Times", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTIMKIEM.Location = new System.Drawing.Point(520, 429);
            this.btnTIMKIEM.Name = "btnTIMKIEM";
            this.btnTIMKIEM.Size = new System.Drawing.Size(155, 46);
            this.btnTIMKIEM.TabIndex = 4;
            this.btnTIMKIEM.TabStop = false;
            this.btnTIMKIEM.Text = "Tìm kiếm DL";
            this.btnTIMKIEM.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.btnTIMKIEM.UseVisualStyleBackColor = true;
            this.btnTIMKIEM.Click += new System.EventHandler(this.btnNHAP1_Click);
            // 
            // cboKhoa
            // 
            this.cboKhoa.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboKhoa.FormattingEnabled = true;
            this.cboKhoa.Items.AddRange(new object[] {
            "Khoa công nghệ thông tin ",
            "Khoa trí tuệ nhân tạo",
            "Khoa thông kê ",
            "Khoa khoa học cơ bản",
            "Khoa kinh tế"});
            this.cboKhoa.Location = new System.Drawing.Point(227, 426);
            this.cboKhoa.Name = "cboKhoa";
            this.cboKhoa.Size = new System.Drawing.Size(248, 30);
            this.cboKhoa.TabIndex = 5;
            this.cboKhoa.Text = "Lựa chon khoa/viện của bạn";
            this.cboKhoa.SelectedIndexChanged += new System.EventHandler(this.cboKhoa_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(77, 429);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Khoa viện";
            this.label3.Click += new System.EventHandler(this.label1_Click);
            // 
            // frmNhapDuLieu1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(922, 556);
            this.Controls.Add(this.cboKhoa);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnXOADL);
            this.Controls.Add(this.btnTIMKIEM);
            this.Controls.Add(this.btnNHAP1);
            this.Controls.Add(this.textTieuDe);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblMaKhau);
            this.Controls.Add(this.lblHoTen);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textPass);
            this.Controls.Add(this.textHOTEN);
            this.Name = "frmNhapDuLieu1";
            this.Text = "frmNhapDuLieu1";
            this.Load += new System.EventHandler(this.frmNhapDuLieu1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textHOTEN;
        private System.Windows.Forms.TextBox textPass;
        private System.Windows.Forms.Label lblHoTen;
        private System.Windows.Forms.Label lblMaKhau;
        private System.Windows.Forms.TextBox textTieuDe;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnNHAP1;
        private System.Windows.Forms.Button btnXOADL;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnThoat;
        private System.Windows.Forms.Button btnTIMKIEM;
        private System.Windows.Forms.ComboBox cboKhoa;
        private System.Windows.Forms.Label label3;
    }
}