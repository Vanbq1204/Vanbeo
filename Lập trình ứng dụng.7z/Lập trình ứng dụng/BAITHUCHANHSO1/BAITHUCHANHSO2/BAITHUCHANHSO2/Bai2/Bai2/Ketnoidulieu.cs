﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace Bai2
{
    internal class Ketnoidulieu
    {
        public SqlConnection cnn;
        public SqlCommand cmd;
        public DataTable dta;
        public SqlDataAdapter ada;

        public void Ketnoi_Dulieu()
        {
            string strKetNoi = @"Data Source= VANDEPZAI\KTEAM;Initial Catalog=QUANLYSV123;Integrated Security=True";
            cnn = new SqlConnection(strKetNoi);
            cnn.Open();
        }
        public void HuyKetNoi()
        {

        }
        public DataTable Lay_DulieuBang(string sql)
        {
            Ketnoidulieu();
            ada = new SqlDataAdapter(sql, cnn);

        }
    }
}
